# Contributing Guidelines

Thank you for your interest in contributing to the Medical Image Gallery project! This document provides guidelines and instructions for contributing.

## Code of Conduct

Please be respectful and considerate of others when contributing to this project. We aim to foster an inclusive and welcoming community.

## Getting Started

1. Fork the repository
2. Clone your fork: `git clone https://github.com/your-username/medical-image-gallery.git`
3. Create a new branch: `git checkout -b feature/your-feature-name`
4. Install dependencies: `npm install`
5. Start the development server: `npm run dev`

## Development Workflow

### Code Style

We follow these coding conventions:

- Use 2 spaces for indentation
- Use camelCase for variable and function names
- Use PascalCase for class names
- Use meaningful variable and function names
- Add comments for complex logic

### Commit Messages

Please use clear and descriptive commit messages following this format:

```
type: Short description (max 50 chars)

Longer description if necessary explaining the context of the change and
why it was made. (optional, wrap at 72 characters)
```

Types:
- `feat`: A new feature
- `fix`: A bug fix
- `docs`: Documentation changes
- `style`: Code style changes (formatting, missing semicolons, etc)
- `refactor`: Code changes that neither fix bugs nor add features
- `perf`: Performance improvements
- `test`: Adding or updating tests
- `chore`: Changes to build process, dependencies, etc.

### Pull Requests

1. Update your fork to the latest upstream changes
2. Push your branch to your fork
3. Create a pull request from your branch to the main repository
4. Provide a clear description of the changes in your pull request
5. Link any related issues

## Feature Requests and Bug Reports

Please use the GitHub Issues section to report bugs or request features.

### Bug Reports

When reporting bugs, please include:

- A clear and descriptive title
- Steps to reproduce the bug
- Expected behavior
- Actual behavior
- Browser and operating system information
- Screenshots if applicable

### Feature Requests

When requesting features, please include:

- A clear and descriptive title
- Detailed description of the feature
- Explanation of why this feature would be useful
- Any relevant examples or mockups

## Project Structure

```
/
├── images/              # Sample medical images
├── index.html          # Main HTML structure
├── style.css           # CSS styles
├── script.js           # JavaScript functionality
├── server.js           # Node.js server
├── package.json        # Project configuration
└── README.md           # Project documentation
```

## Testing

Currently, we don't have automated tests. However, please manually test your changes thoroughly before submitting a pull request.

## License

By contributing to this project, you agree that your contributions will be licensed under the project's MIT license.