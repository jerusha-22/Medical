# Interactive Medical Image Gallery

A fully responsive and interactive medical image gallery with advanced filtering, sorting, and preview capabilities. This project demonstrates modern front-end development skills with vanilla JavaScript, CSS, and HTML, with special attention to responsive design for optimal viewing on all devices (mobile, tablet, and desktop).

## Features

- **Comprehensive Responsive Design**: 
  - Fully optimized for mobile, tablet, and desktop viewing
  - Adaptive layout with tailored experiences for different screen sizes
  - Fluid typography and spacing that scales with viewport size
  - Touch-friendly interface elements for mobile users
- **Advanced Filtering**: Filter images by modality and study type
- **Sorting Options**: Sort by date, modality, or study type
- **Interactive Modal Preview**: View images in a full-screen modal with metadata
- **Keyboard Navigation**: Navigate through gallery and modal using keyboard
- **Touch Support**: Swipe gestures for mobile navigation
- **Performance Optimizations**: Lazy loading, debounced resize handling, document fragments
- **Accessibility Features**: ARIA attributes, keyboard focus management, semantic HTML

## Getting Started

### Prerequisites

- Node.js (for development server)

### Installation

```bash
# Clone the repository (if using Git)
# git clone <repository-url>

# Navigate to the project directory
cd medical-image-gallery

# Install dependencies
npm install
```

### Running the Application

```bash
# Start development server
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

## Project Structure

```
/
├── images/              # Sample medical images
├── index.html          # Main HTML structure
├── style.css           # CSS styles
├── script.js           # JavaScript functionality
├── package.json        # Project configuration
└── README.md           # Project documentation
```

## Technical Implementation

- **Vanilla JavaScript**: No frameworks, demonstrating core JavaScript skills
- **CSS3**: Modern CSS techniques including Flexbox, Grid, and animations
- **Advanced Responsive Design**: 
  - Mobile-first approach with strategic breakpoints at 1200px, 1024px, 768px, 600px, 480px, and 360px
  - Fluid layouts that adapt to any screen size
  - Optimized media handling for different devices
  - Responsive typography and UI components
- **Performance**: Optimized for speed with lazy loading and efficient DOM manipulation
- **Accessibility**: ARIA attributes and keyboard navigation

## Future Enhancements

- Integration with backend API for real medical image data
- Advanced search functionality
- User authentication and personalized views
- Image annotation capabilities
- Comparison view for multiple images

## License

MIT