# Deployment Guide

This document provides instructions for deploying the Medical Image Gallery application to various environments.

## Local Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

The application will be available at http://localhost:3000

## Production Build

```bash
# Create production build
npm run build

# Start production server
npm start
```

The application will be available at http://localhost:3000

## Deployment Options

### Option 1: Static Hosting (GitHub Pages, Netlify, Vercel)

This application can be deployed as a static site since it uses client-side JavaScript.

#### GitHub Pages

1. Create a GitHub repository for your project
2. Push your code to the repository
3. Go to Settings > Pages
4. Select the branch to deploy (usually `main` or `master`)
5. Set the folder to `/` (root) or `/dist` if you've built the project
6. Click Save

#### Netlify

1. Create a Netlify account
2. Connect your GitHub repository
3. Set build command to `npm run build`
4. Set publish directory to `.dist`
5. Deploy

#### Vercel

1. Create a Vercel account
2. Connect your GitHub repository
3. Set build command to `npm run build`
4. Set output directory to `.dist`
5. Deploy

### Option 2: Node.js Server (Heroku, DigitalOcean, AWS)

For deployments that need the custom Node.js server:

#### Heroku

1. Create a Heroku account
2. Install Heroku CLI: `npm install -g heroku`
3. Login to Heroku: `heroku login`
4. Create a new Heroku app: `heroku create your-app-name`
5. Add a Procfile to your project root with: `web: npm start`
6. Push to Heroku: `git push heroku main`

#### DigitalOcean App Platform

1. Create a DigitalOcean account
2. Create a new App
3. Connect your GitHub repository
4. Set build command to `npm run build`
5. Set run command to `npm start`
6. Deploy

#### AWS Elastic Beanstalk

1. Create an AWS account
2. Install AWS CLI and EB CLI
3. Initialize EB: `eb init`
4. Create environment: `eb create`
5. Deploy: `eb deploy`

## Environment Variables

For production deployments, consider setting these environment variables:

- `PORT`: The port on which the server will run (default: 3000)
- `NODE_ENV`: Set to `production` for production environments

## HTTPS Configuration

For production deployments, it's recommended to configure HTTPS:

- When using platforms like Netlify, Vercel, or Heroku, HTTPS is typically configured automatically
- For custom server deployments, consider using a reverse proxy like Nginx with Let's Encrypt certificates

## Performance Considerations

- Enable gzip compression for static assets
- Configure proper cache headers for images and static files
- Consider using a CDN for serving images
- Implement a service worker for offline capabilities

## Responsive Design Implementation

This application features comprehensive responsive design optimized for all device sizes:

- **Desktop (1200px+)**: Full-featured experience with optimized grid layout
- **Large Tablets (1024px-1200px)**: Adjusted grid and spacing for comfortable viewing
- **Tablets (768px-1024px)**: Reorganized layout with vertical filter arrangement
- **Large Mobile (600px-768px)**: Optimized for touch with larger tap targets
- **Mobile (480px-600px)**: Simplified layout with full-width elements
- **Small Mobile (< 480px)**: Highly optimized for small screens with essential content prioritization

The responsive implementation uses a combination of:
- Fluid layouts with CSS Grid and Flexbox
- Strategic media queries at key breakpoints
- Relative units (rem, em, %) for scalable typography and spacing
- Touch-optimized interactions for mobile users