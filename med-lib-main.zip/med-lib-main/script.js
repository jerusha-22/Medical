// Medical image data with educational descriptions
const mockImages = [
  {
    id: 1,
    url: 'images/mri.jpeg',
    modality: 'MRI',
    alt: 'Brain MRI showing normal anatomy',
    description: 'T1-weighted sagittal brain MRI showing normal anatomical structures',
    date: '2023-05-15',
    studyType: 'Brain'
  },
  {
    id: 2,
    url: 'images/ct.png',
    modality: 'CT',
    alt: 'Chest CT scan',
    description: 'Axial chest CT scan showing lung window settings',
    date: '2023-06-22',
    studyType: 'Chest'
  },
  {
    id: 3,
    url: 'images/ultrasound.jpg',
    modality: 'Ultrasound',
    alt: 'Thyroid Ultrasound',
    description: 'Longitudinal ultrasound view of the thyroid gland',
    date: '2023-04-10',
    studyType: 'Thyroid'
  },
  {
    id: 4,
    url: 'images/knee-mri.jpeg',
    modality: 'MRI',
    alt: 'Knee MRI',
    description: 'Sagittal T2-weighted MRI of the knee showing meniscus and ligaments',
    date: '2023-07-05',
    studyType: 'Knee'
  },
  {
    id: 5,
    url: 'images/abdominal-ct.jpg',
    modality: 'CT',
    alt: 'Abdominal CT',
    description: 'Contrast-enhanced CT of the abdomen showing liver and kidneys',
    date: '2023-08-18',
    studyType: 'Abdomen'
  },
  {
    id: 6,
    url: 'images/cardiac-ultrasound.jpeg',
    modality: 'Ultrasound',
    alt: 'Cardiac Ultrasound',
    description: 'Four-chamber view of the heart on echocardiogram',
    date: '2023-09-03',
    studyType: 'Cardiac'
  },
];

// Generate additional mock images for testing scalability
const generateAdditionalImages = () => {
  const baseImages = [...mockImages];
  const additionalImages = [];
  
  // Generate 30 more images (6 original + 30 new = 36 total)
  for (let i = 0; i < 30; i++) {
    const baseImage = baseImages[i % baseImages.length];
    additionalImages.push({
      id: baseImages.length + i + 1,
      url: baseImage.url,
      modality: baseImage.modality,
      alt: `${baseImage.alt} (Copy ${i + 1})`,
      description: `${baseImage.description} (Additional study ${i + 1})`,
      date: new Date(new Date(baseImage.date).getTime() + (i * 86400000)).toISOString().split('T')[0], // Add i days
      studyType: baseImage.studyType
    });
  }
  
  return [...baseImages, ...additionalImages];
};

// Uncomment the line below to test with a larger dataset
// const mockImages = generateAdditionalImages();

// State management
let currentImages = [...mockImages];
let currentImageIndex = 0;
let isZoomed = false;
let touchStartX = 0;
let touchStartY = 0;
let activeFilters = {
  modality: 'all',
  studyType: 'all'
};
let activeSortOrder = 'date-desc';

// DOM Elements
const gallery = document.getElementById('gallery');
const modal = document.getElementById('image-modal');
const modalImage = document.getElementById('modal-image');
const modalTitle = document.getElementById('modal-title');
const modalDescription = document.getElementById('modal-description');
const modalModality = document.getElementById('modal-modality');
const modalStudyType = document.getElementById('modal-study-type');
const modalDate = document.getElementById('modal-date');
const currentImageNumber = document.getElementById('current-image-number');
const totalImagesNumber = document.getElementById('total-images-number');
const closeBtn = document.getElementById('close-modal');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');
const modalityFilter = document.getElementById('modality-filter');
const studyFilter = document.getElementById('study-filter');
const sortOrder = document.getElementById('sort-order');

// Loading state management
function showLoading(element) {
  element.classList.add('loading');
}

function hideLoading(element) {
  element.classList.remove('loading');
}

// Error handling
function handleImageError(img) {
  img.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"%3E%3Cpath fill="%23666" d="M21 5v14H3V5h18m0-2H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-9 5c1.65 0 3 1.35 3 3s-1.35 3-3 3-3-1.35-3-3 1.35-3 3-3zm0-2c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5z"/%3E%3C/svg%3E';
  img.classList.add('error');
}

// Create gallery items with descriptions and loading states
function renderGallery() {
  gallery.innerHTML = '';
  
  // Create a document fragment for better performance
  const fragment = document.createDocumentFragment();
  
  currentImages.forEach((image, index) => {
    const item = document.createElement('div');
    item.className = 'gallery-item';
    item.setAttribute('tabindex', '0'); // Make focusable for keyboard navigation
    item.setAttribute('role', 'gridcell');
    item.setAttribute('aria-label', image.alt);
    item.style.setProperty('--i', index + 1);

    // Create loading spinner
    const spinner = document.createElement('div');
    spinner.className = 'loading-spinner';
    item.appendChild(spinner);
    
    // Create image with lazy loading
    const img = new Image();
    showLoading(item);

    img.onload = () => hideLoading(item);
    img.onerror = () => {
      hideLoading(item);
      handleImageError(img);
    };

    // Use data-src for intersection observer lazy loading
    if (observer) {
      img.setAttribute('data-src', image.url);
      img.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1 1"%3E%3C/svg%3E'; // Tiny placeholder
    } else {
      img.src = image.url; // Fallback for browsers without IntersectionObserver
    }
    
    img.alt = image.alt;
    img.loading = 'lazy';
    item.insertBefore(img, item.firstChild);
    
    // Create modality badge
    const modalityBadge = document.createElement('span');
    modalityBadge.className = 'modality-badge';
    modalityBadge.textContent = image.modality;
    item.appendChild(modalityBadge);
    
    // Create study type badge
    const studyTypeBadge = document.createElement('span');
    studyTypeBadge.className = 'study-type-badge';
    studyTypeBadge.textContent = image.studyType;
    item.appendChild(studyTypeBadge);
    
    // Create date badge
    const dateBadge = document.createElement('span');
    dateBadge.className = 'date-badge';
    dateBadge.textContent = new Date(image.date).toLocaleDateString();
    item.appendChild(dateBadge);
    
    // Create description
    const description = document.createElement('div');
    description.className = 'image-description';
    description.textContent = image.description;
    item.appendChild(description);

    // Add event listeners
    item.addEventListener('click', () => openModal(index));
    
    // Add keyboard support
    item.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        openModal(index);
      }
    });
    
    fragment.appendChild(item);
  });
  
  gallery.appendChild(fragment);
  
  // Observe all gallery items for lazy loading
  if (observer) {
    document.querySelectorAll('.gallery-item').forEach(item => {
      observer.observe(item);
    });
  }
}

// Modal functions with zoom support
function openModal(index) {
  currentImageIndex = index;
  updateModalImage();
  modal.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  modal.classList.add('hidden');
  document.body.style.overflow = '';
  isZoomed = false;
  modalImage.style.transform = '';
}

function updateModalImage() {
  const image = currentImages[currentImageIndex];
  showLoading(modal);

  modalImage.onload = () => hideLoading(modal);
  modalImage.onerror = () => {
    hideLoading(modal);
    handleImageError(modalImage);
  };

  // Update image and alt text
  modalImage.src = image.url;
  modalImage.alt = image.alt;
  
  // Update modal title with image alt text
  modalTitle.textContent = image.alt;
  
  // Update metadata fields
  modalDescription.textContent = image.description;
  modalModality.textContent = image.modality;
  modalStudyType.textContent = image.studyType;
  
  // Format date for display
  const dateObj = new Date(image.date);
  const formattedDate = dateObj.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  modalDate.textContent = formattedDate;
  
  // Update image counter
  currentImageNumber.textContent = currentImageIndex + 1;
  totalImagesNumber.textContent = currentImages.length;

  updateNavigationButtons();
  isZoomed = false;
  modalImage.style.transform = '';
}

function updateNavigationButtons() {
  prevBtn.disabled = currentImageIndex === 0;
  nextBtn.disabled = currentImageIndex === currentImages.length - 1;
}

function showPreviousImage() {
  if (currentImageIndex > 0) {
    currentImageIndex--;
    updateModalImage();
  }
}

function showNextImage() {
  if (currentImageIndex < currentImages.length - 1) {
    currentImageIndex++;
    updateModalImage();
  }
}

// Zoom functionality
function toggleZoom(event) {
  if (event.target === modalImage) {
    isZoomed = !isZoomed;
    if (isZoomed) {
      const rect = modalImage.getBoundingClientRect();
      const x = event.clientX - rect.left;
      const y = event.clientY - rect.top;
      const percentX = x / rect.width * 100;
      const percentY = y / rect.height * 100;
      modalImage.style.transform = `scale(2)`;
      modalImage.style.transformOrigin = `${percentX}% ${percentY}%`;
    } else {
      modalImage.style.transform = '';
      modalImage.style.transformOrigin = '';
    }
  }
}

// Touch gesture handling
function handleTouchStart(event) {
  touchStartX = event.touches[0].clientX;
  touchStartY = event.touches[0].clientY;
}

function handleTouchMove(event) {
  if (!touchStartX || !touchStartY) return;

  const touchEndX = event.touches[0].clientX;
  const touchEndY = event.touches[0].clientY;
  const deltaX = touchStartX - touchEndX;
  const deltaY = touchStartY - touchEndY;

  // Horizontal swipe detection
  if (Math.abs(deltaX) > Math.abs(deltaY)) {
    if (deltaX > 50) showNextImage();
    if (deltaX < -50) showPreviousImage();
  }

  touchStartX = 0;
  touchStartY = 0;
}

// Filter and sort functions
function applyFiltersAndSort() {
  gallery.classList.add('filtering');
  
  setTimeout(() => {
    // Start with all images
    let filteredImages = [...mockImages];
    
    // Apply modality filter if not 'all'
    if (activeFilters.modality !== 'all') {
      filteredImages = filteredImages.filter(image => image.modality === activeFilters.modality);
    }
    
    // Apply study type filter if not 'all'
    if (activeFilters.studyType !== 'all') {
      filteredImages = filteredImages.filter(image => image.studyType === activeFilters.studyType);
    }
    
    // Apply sorting
    switch (activeSortOrder) {
      case 'date-desc':
        filteredImages.sort((a, b) => new Date(b.date) - new Date(a.date));
        break;
      case 'date-asc':
        filteredImages.sort((a, b) => new Date(a.date) - new Date(b.date));
        break;
      case 'modality':
        filteredImages.sort((a, b) => a.modality.localeCompare(b.modality));
        break;
      case 'study-type':
        filteredImages.sort((a, b) => a.studyType.localeCompare(b.studyType));
        break;
    }
    
    currentImages = filteredImages;
    renderGallery();
    gallery.classList.remove('filtering');
    
    // Update total count in modal
    totalImagesNumber.textContent = currentImages.length;
  }, 300);
}

// Event listeners
closeBtn.addEventListener('click', closeModal);
prevBtn.addEventListener('click', showPreviousImage);
nextBtn.addEventListener('click', showNextImage);
modalImage.addEventListener('click', toggleZoom);

// Filter and sort event listeners
modalityFilter.addEventListener('change', (e) => {
  activeFilters.modality = e.target.value;
  applyFiltersAndSort();
});

studyFilter.addEventListener('change', (e) => {
  activeFilters.studyType = e.target.value;
  applyFiltersAndSort();
});

sortOrder.addEventListener('change', (e) => {
  activeSortOrder = e.target.value;
  applyFiltersAndSort();
});

// Lazy loading with Intersection Observer for better performance
let observer;
if ('IntersectionObserver' in window) {
  observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const lazyImage = entry.target.querySelector('img');
        if (lazyImage && lazyImage.dataset.src) {
          lazyImage.src = lazyImage.dataset.src;
          lazyImage.removeAttribute('data-src');
        }
        observer.unobserve(entry.target);
      }
    });
  }, { rootMargin: '200px' });
}

// Touch events
modal.addEventListener('touchstart', handleTouchStart);
modal.addEventListener('touchmove', handleTouchMove);

// Keyboard navigation
document.addEventListener('keydown', (e) => {
  if (modal.classList.contains('hidden')) return;

  switch (e.key) {
    case 'ArrowLeft':
      showPreviousImage();
      break;
    case 'ArrowRight':
      showNextImage();
      break;
    case 'Escape':
      closeModal();
      break;
    case ' ':
      e.preventDefault();
      toggleZoom({ target: modalImage });
      break;
  }
});

// Close modal when clicking outside the image
modal.addEventListener('click', (e) => {
  if (e.target === modal) {
    closeModal();
  }
});

// Initialize the gallery with default settings
function initializeGallery() {
  // Set default filters and sort order
  activeFilters.modality = 'all';
  activeFilters.studyType = 'all';
  activeSortOrder = 'date-desc';
  
  // Update select elements to match default state
  modalityFilter.value = activeFilters.modality;
  studyFilter.value = activeFilters.studyType;
  sortOrder.value = activeSortOrder;
  
  // Apply initial filters and render gallery
  applyFiltersAndSort();
  
  // Add keyboard navigation for the gallery grid
  gallery.addEventListener('keydown', handleGalleryKeyNavigation);
}

// Handle keyboard navigation within the gallery grid
function handleGalleryKeyNavigation(e) {
  if (!e.target.classList.contains('gallery-item')) return;
  
  const items = Array.from(gallery.querySelectorAll('.gallery-item'));
  const currentIndex = items.indexOf(e.target);
  const columns = Math.floor(gallery.offsetWidth / items[0].offsetWidth);
  
  let nextIndex;
  
  switch (e.key) {
    case 'ArrowRight':
      nextIndex = currentIndex + 1;
      if (nextIndex < items.length) items[nextIndex].focus();
      break;
    case 'ArrowLeft':
      nextIndex = currentIndex - 1;
      if (nextIndex >= 0) items[nextIndex].focus();
      break;
    case 'ArrowDown':
      nextIndex = currentIndex + columns;
      if (nextIndex < items.length) items[nextIndex].focus();
      break;
    case 'ArrowUp':
      nextIndex = currentIndex - columns;
      if (nextIndex >= 0) items[nextIndex].focus();
      break;
  }
}

// Initialize the gallery when the page loads
document.addEventListener('DOMContentLoaded', initializeGallery);

// Add resize handler for responsive adjustments
window.addEventListener('resize', debounce(() => {
  // Recalculate layout if needed
  updateGalleryLayout();
}, 250));

// Debounce function to limit rapid firing of resize events
function debounce(func, wait) {
  let timeout;
  return function() {
    const context = this;
    const args = arguments;
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(context, args), wait);
  };
}

// Update gallery layout on resize
function updateGalleryLayout() {
  // This function can be expanded to handle any layout adjustments needed on resize
  // For now, it's a placeholder for future enhancements
  console.log('Window resized, updating layout if needed');
}
